x1 = float (input("Digite o primeiro valor:"))
y1 = float (input("Digite o segundo valor:"))
x2 = float (input("Digite o terceiro valor:"))
y2 = float (input("Digite o quarto valor:"))

distância = (x2- y2)**2 + (x1 - y1)**2 **0.5


print(f"A distância euclidia é: {distância:.2f}")