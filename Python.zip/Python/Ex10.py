idade = int (input("Digite sua idade:"))

dias = idade * 365
print(f"Você já viveu {dias} dias")