base = int (input("Digite a base:"))
expoente = int (input("Digite o expoente:"))

potencia = base ** expoente
print(f"Resultado: {potencia}")
