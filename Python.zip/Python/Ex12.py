preco = float(input("Digite o preço:"))

print("O preço é R$:" + str(preco))
