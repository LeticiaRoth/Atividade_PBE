raio = int (input("Digite o raio:"))
area = 3.14  * (raio ** 2)

print(f"A área é {area:}")