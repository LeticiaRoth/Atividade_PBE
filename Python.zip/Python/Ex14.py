a = int (input("Digite o primeiro número:"))
b = int (input("Digite o segundo número:"))

a, b = b, a

print(f"A = {a} e B {b}")
