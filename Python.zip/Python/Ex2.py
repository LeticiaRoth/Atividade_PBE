a = 10
b = 5
soma = a +b
sub = a - b
mult = a * b
div = a / b
print(f"\nSoma: {soma}, \nSubtração: {sub},  \nMultiplicação: {mult} e \nDivisão: {div}")