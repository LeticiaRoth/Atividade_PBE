preco = 50
desconto = 10
vfinal = 50 - 10
print(f"O resultado é: {vfinal}")