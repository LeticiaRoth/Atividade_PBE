resultado = 10 + (5 * 2)
print(f"O resultado da expressão é: {resultado}")
