texto = 150
n = int(texto) * 2
print(f"Resultado: {n}")