n1 = int (input("Digite o primeiro número:"))
n2 = int (input("Digite o segundo número:"))

soma = n1 + n2
print(f"O resultado é: {soma}")