x = int (input("Digite o primeiro número:"))
y = int (input("Digite o primeiro número:"))

divisao = x // y
print(f"Divisão inteira é: {divisao}")
