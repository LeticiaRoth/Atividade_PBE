n1 = int (input("Digite o primeiro número:"))
n2 = int (input("Digite o segundo número:"))

print(n1 > n2)
